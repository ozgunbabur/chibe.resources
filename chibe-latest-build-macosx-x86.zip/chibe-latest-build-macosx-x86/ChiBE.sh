java -Xmx1024M -XstartOnFirstThread -d32 -da -jar ChiBE-macosx.jar
